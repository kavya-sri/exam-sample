package com.dthoperator.service;

import java.util.ArrayList;
import com.dthoperator.bean.RechargeDetails;

public class RechargeCollectionHelper {
		
	private  static ArrayList<RechargeDetails> OperatorList=null;
		
		static
		{
			OperatorList=new ArrayList<RechargeDetails>();
			RechargeDetails Rd1=new RechargeDetails("Airtel",1089343431,"Monthly",210,4567);
			RechargeDetails Rd2=new RechargeDetails("DishTV", 303322123, "Yearly", 1260, 2345);
			RechargeDetails Rd3=new RechargeDetails("Reliance", 892343430, "Quaterly", 650, 1234);
			
			OperatorList.add(Rd1);
			OperatorList.add(Rd2);
			OperatorList.add(Rd3);
		}
		public ArrayList<RechargeDetails> getItems()
		{
			return OperatorList;
		}
		public static void addRechargeDetails(RechargeDetails rechargeDetails) 
		{			
			OperatorList.add(rechargeDetails);				
		}
		public void displayRechargeDetails(int transactionID) 
		{
			// TODO Auto-generated method stub
			System.out.println("Transaction ID..");
		}

}
