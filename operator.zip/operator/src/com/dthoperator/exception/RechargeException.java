package com.dthoperator.exception;

public class RechargeException extends Exception{
	private static final long serialVersionUID = 1L;
	public RechargeException()
	{
		super();
	}
	public RechargeException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) 
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}
	public RechargeException(String message, Throwable cause) 
	{
		super(message, cause);
	}
	public RechargeException(String message) 
	{
		super(message);			
	}
	public RechargeException(Throwable cause) 
	{
		super(cause);			
	}

}
